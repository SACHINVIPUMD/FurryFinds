import p1_img from './dog1.jpg'
import p2_img from './dog2.jpeg'
import p3_img from './dog3.jpg'
import p4_img from './dog4.jpg'
let data_product = [
  {
    id:1,
    name:"adorable beagle puppy dogs with ease and trust.",
    image:p1_img,
    new_price:50.00,
    old_price:80.50,
  },
  {id:2,
    name:"adorable German Shepherd puppy dogs with ease and trust.",
    image:p2_img,
    new_price:85.00,
    old_price:120.50,
  },
  {id:3,
    name:"adorable Golden Retriver puppy dogs with ease and trust.",
    image:p3_img,
    new_price:60.00,
    old_price:100.50,
  },
  {id:4,
    name:"adorable Labordor puppy dogs with ease and trust.",
    image:p4_img,
    new_price:100.00,
    old_price:150.00,
  },
];

export default data_product;
